##############################################
# Author: Justin Sousa & Umut Oktay
# Class: CCT 111, Winter 2019
# Anaylitcal Visualization Project
# 12/06/19
#
# Description: A prgram that will open a csv file and extract the data in a collected manor, the data will be sorted according to the users input. Being which year and what income level they would like to look at. That information will then be put into a new file, FINISH THIS. 
# No sources to cite. 
##############################################

import csv
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

def open_file():
    n = True
    file_name = "measles.csv";
    while n:
        try:
            f = open(str(file_name), 'r')
            if f:
                return f;
        except IOError:
            n = False
            print("The file couldn't be found")
            exit()

def program(f):
    
    str_level = "";
    df = pd.read_csv('measles.csv')
    total_percentage = 0 
    filepath = 'measles.csv'
    countries = []    
    low_country = [0]
    high_country = [50]
    high = 100
    low = 0
         
    with open(filepath) as fp:
        
        line = fp.readline()
        cnt = 1
        while line:
           # print("Line {}: {}".format(cnt, line.strip()))
            line = fp.readline()
            countries.append("{}".format(line.strip()))
            cnt += 1    
        country = list(csv.reader(countries))
        ''' Used to get the names of the countries that fall into that income level '''
        selected_Countries = []
        selected_Countries_Data = []    
    
    ''' Need to make it so that it requires the user to correct input. A number between 1980 and 2017, and for the income it must be either 1 , 2 , 3, 4 '''
    
    while True:
        
        year = (input('Enter year between 2017 to 1980: '))
        if year.upper() == "ALL":                                  
            for one in country:   
                for two in one:
                    if one[0] in selected_Countries:
                        data_Set = 2
                        selected_Countries_Data.append(one[data_Set:])
                        if int(one[data_Set]) > int(high_country[0]):
                            high_country = one[data_Set] + one[0]
                        elif int(one[data_Set]) < int(high_country[0]) and int(one[data_Set]) > int(low_country[0]):
                            low_country = one[data_Set] + one[0]
                            
                    else:
                        selected_Countries.append(one[0])
                        data_Set = 2
                        selected_Countries_Data.append(one[data_Set:])
                        if int(one[data_Set]) > int(high_country[0]):
                            high_country = one[data_Set] + one[0]
                        elif int(one[data_Set]) < int(high_country[0]) and int(one[data_Set]) > int(low_country[0]):
                            low_country = one[data_Set] + ione[0]                   
                        
            print(selected_Countries[0:])
            print(selected_Countries_Data[0:])
            print(high_country)
            print(low_country)
            break            
        else:
            income = int(input('Enter Income Level from set{1,2,3,4} : '))
        
            if income == 1:
                str_level = "WB_LI";
            if income == 2:
                str_level = "WB_LMI";
            if income == 3:
                str_level = "WB_UMI";
            if income == 4: 
                str_level = "WB_HI";            
        
            
            if int(year) < 1980 or int(year) > 2017 or income > 4 or income < 1:
                ''' Will check to see if the input is in the allocated time frame '''
            
                print("You gave the wrong input")
            
            else:
                ''' Will run if the user gave a time between 2017 - 1980 and the gave a proper income level. This code will will loop through the country list, then loop through the that list, and if it is at the income level then it will append the name of that country to a list ( selected_Countries ) (line 87) and all of the number of that country to a different list ( selected_Countries_Data ) (line 88) '''
            
                for one in country:
                    for two in one:
                        if two == str_level:
                            selected_Countries.append(one[0])
                            data_Set = 2017 - int(year) + 2
                            selected_Countries_Data.append(one[data_Set])
                            if int(one[data_Set]) > int(high_country[0]):
                                high_country = one[data_Set]
                            elif int(one[data_Set]) < int(high_country[0]) and int(one[data_Set]) > int(low_country[0]):
                                low_country = one[data_Set]                        
            
                if country:
                    print("Count of report = "+str(len(country)))
                    sum_selected_countries = 0
                    for i in selected_Countries_Data:
                        sum_selected_countries = int(i) + sum_selected_countries
                    print("Average percentage = " , (sum_selected_countries) / int((len(country))), "%")                    
                    print("Country with lowest percentage = " , int(low_country[0]), "%")
                    print("Country with highest percentage = " , high_country, "%")
                else:
                    print('No data to display')
                            
                def graph():
                    plt.plot(selected_Countries, selected_Countries_Data)
                    plt.xlabel('Country List')
                    plt.ylabel('Percentages for Countries')
                    plt.title('Data for the Year 2016 and Income Level 3')
                    plt.show()
                
         
def output():
    output_name = input("Enter the name of the output file: ")
    with open(output_name, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(program)
        

    
def main():
    f = open_file();
    program(f)
    graph()
main()




